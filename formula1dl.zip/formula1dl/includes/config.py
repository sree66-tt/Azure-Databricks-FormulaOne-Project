# Databricks notebook source
raw_folder_path = "/mnt/formula1dlsree/raw"
processed_folder_path = "/mnt/formula1dlsree/transforrmed"
presentation_folder_path = "/mnt/formula1dlsree/presented"